#include <stdlib.h> 
#include <stdio.h> 
#include <limits.h>
#include "../header/vector.h"
int main() {
    SVector v;
    init_vector(&v);

    pushback(&v, "Hello");
    print_vector(v);
    pushback(&v, "a");
    print_vector(v);
    pushback(&v, "asdasfdv");
    print_vector(v);
    pushback(&v, "eren");
    print_vector(v);

    popback(&v);
    print_vector(v);
    popback(&v);
    print_vector(v);
    popback(&v);
    print_vector(v);
    popback(&v);
    print_vector(v);

    delete_vector(&v);
    print_vector(v);

    pushback(&v, "hello again");
    print_vector(v);
    delete_vector(&v);
    print_vector(v);
    
    return 0;
}