#include <stdlib.h> 
#include <stdio.h> 
#include <string.h>
#include <limits.h>
#include "../header/vector.h"
#include "../header/utils.h"
#include "../header/io.h"
int main() {
    char token[MAX_COMMAND_SIZE], newToken[MAX_COMMAND_SIZE];
    char whitespace[] = " \t\n\f\r\v";
    printf("Enter token: ");
    scanf("%s", token);
    // removeAndSetIO(token);
    char *saveptr = NULL;
    char *arg = strtok_r(token, whitespace, &saveptr);
    while(arg != NULL) {
        strcat(newToken, arg);
        strcat(newToken, " ");
        arg = strtok_r(NULL, whitespace, &saveptr);
    }
    printf("newToken: %s\n", newToken);
    return 0;
}