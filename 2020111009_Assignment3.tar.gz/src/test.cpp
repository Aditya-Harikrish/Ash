if(isPipe(OGtoken)) {
    int numberOfPipes = 0;
    for(size_t i = 0; i < strlen(OGtoken); ++i) {
        if(OGtoken[i] == '|') ++numberOfPipes;
    }
    if(DEBUG) {
        printf("Number of pipes = %d\n", numberOfPipes);
    }
    char *saveptr_pipe = NULL;
    char *command = strtok_r(OGtoken, "|", &saveptr_pipe);
    int commandNum = 0;
    int pipe1[2], pipe2[2];
    while(command != NULL) {
        char commandToExecute[MAX_COMMAND_SIZE];
        strcpy(commandToExecute, command);
        if(DEBUG) {
            printf("commandToExecute: %s\n", commandToExecute);
        }
        if(commandNum % 2 != 0) {
            int z = pipe(pipe2);
            if(z < 0)
                perror("Error: pipe could not be created\n");
        }
        else {
            int z = pipe(pipe1);
            if(z < 0)
                perror("Error: pipe could not be created\n");
        }

        pid_t pid = fork();
        after_fork_check(pid);
        /* Child Process */
        if(pid == 0) {
            if(commandNum == 0) {
                dup2(pipe1[1], STDOUT_FILENO);
                close(pipe1[0]);
                // strcpy(temp, commands[commandNum]);
            }
            else if(commandNum == numberOfPipes - 1) {
                if(commandNum % 2 == 0) {
                    dup2(pipe2[0], STDIN_FILENO);
                }
                else {
                    dup2(pipe1[0], STDIN_FILENO);
                }

            }

            else if(commandNum % 2 == 0) {
                dup2(pipe2[0], STDIN_FILENO);
                close(pipe1[0]);
                dup2(pipe1[1], STDOUT_FILENO);
            }

            else if(commandNum % 2 == 1) {
                close(pipe1[1]);
                dup2(pipe1[0], STDIN_FILENO);
                dup2(pipe2[1], STDOUT_FILENO);
            }

            // strcpy(temp, commands[commandNum]);

            // r = redirection_check(temp);
            // if(r == 1 || r == 2)
            //     redirection(part, ii, commands[commandNum], r);

            // else {
            //     int z = execvp(part[0], part);
            //     if(z < 0)
            //         perror("Error: command not found\n");

            //     if(r == 0)
            //         exit(0);
            // }
            execute(command, homeDirectory, previousDirectory);
            // exit(EXIT_SUCCESS);
        }
        /* Parent process */
        else {
            wait(NULL);

            if(commandNum == 0) {
                close(pipe1[1]);
                // if(inp == 1) {
                //     dup2(oldin, STDIN_FILENO);
                //     // close(ifd);
                // }
            }
            else if(commandNum == numberOfPipes - 1) {
                if(commandNum % 2 == 0) {
                    close(pipe2[0]);
                }
                else {
                    close(pipe1[0]);
                }

                // if(outp == 1) {
                //     dup2(oldout, STDOUT_FILENO);
                //     // close(ofd);
                // }
            }
            else if(commandNum % 2 == 0) {
                close(pipe1[1]);
                close(pipe2[0]);
            }
            else if(commandNum % 2 == 1) {
                close(pipe2[1]);
                close(pipe1[0]);
            }
        }

        int status = execute(commandToExecute, homeDirectory, previousDirectory);
        ++commandNum;
        if(status != NO_ERROR) {
            return status;
        }
        command = strtok_r(NULL, "|", &saveptr_pipe);
    }
    return NO_ERROR;
}