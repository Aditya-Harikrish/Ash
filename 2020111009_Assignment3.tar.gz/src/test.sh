#!/bin/bash
>/home/aditya/file1.txt
while true; do
    echo "Hi" >>/home/aditya/file1.txt
    sleep 1
done
