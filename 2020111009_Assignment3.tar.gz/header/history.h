#include "header.h"
#include "utils.h"

#ifndef HISTORY_H
#define HISTORY_H

void addToHistory(char *command);
int history(char *saveptr);

#endif