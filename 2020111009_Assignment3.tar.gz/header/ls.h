#ifndef LS_H
#define LS_H

#include "header.h"
#include "utils.h"
#include "shell.h"

int ls(char *saveptr, const char homeDirectory[]);

#endif