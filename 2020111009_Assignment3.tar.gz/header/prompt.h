#ifndef PROMPT_H
#define PROMPT_H

#include "header.h"
#include "utils.h"

void prompt(char homeDirectory[]);

#endif